import re,json,sys,unicodedata,os
out=sys.argv[1]; SRCS=sys.argv[2:]
V=json.load(open('/mnt/user-data/uploads/Bible app/Claude outputs/vcounts_es.json'))
def norm(s):
    s=unicodedata.normalize('NFD',s.lower()); s=''.join(c for c in s if unicodedata.category(c)!='Mn')
    return re.sub(r'[^a-z0-9]','',s)
ABBR="""gen genesis:0;exo exodo:1;lev levitico:2;num numeros:3;deut deu deuteronomio:4;jos josue:5;jue jueces:6;rut:7;1sam:8;2sam:9;1rey 1reyes:10;2rey 2reyes:11;1cron 1cronicas:12;2cron 2cronicas:13;esd esdras:14;neh nehemias:15;est ester:16;job:17;sal salmos salmo:18;prov proverbios:19;ecl eclesiastes:20;cant cantares:21;isa isaias:22;jer jeremias:23;lam lamentaciones:24;eze ezeq ezequiel:25;dan daniel:26;ose oseas:27;joel:28;amos:29;abd abdias:30;jon jonas:31;miq miqueas:32;nah nahum:33;hab habacuc:34;sof sofonias:35;hag hageo:36;zac zacarias:37;mal malaquias:38;mat mateo:39;mar marcos:40;luc lucas:41;juan:42;hech hechos:43;rom romanos:44;1cor:45;2cor:46;gal galatas:47;efe efesios:48;fil filipenses:49;col colosenses:50;1tes:51;2tes:52;1tim:53;2tim:54;tito:55;filem filemon:56;heb hebreos:57;sant santiago:58;1ped:59;2ped:60;1juan:61;2juan:62;3juan:63;jud judas:64;apoc apocalipsis:65"""
B={}
for ent in ABBR.split(';'):
    names,idx=ent.rsplit(':',1)
    for n in names.split(): B[norm(n)]=int(idx)
ONECH={30,56,62,63,64}
BOOKNAMES={'genesis':0,'exodo':1,'levitico':2,'numeros':3,'deuteronomio':4}
warn=[]
def vrange(spec):
    out=[]
    for p in re.split(r'\s*,\s*',spec.strip()):
        m=re.match(r'^(\d+)(?:\s*[-–]\s*(\d+))?$',p)
        if not m: return None
        a=int(m.group(1)); b=int(m.group(2) or a)
        out+=list(range(a,b+1))
    return out
def parse_refs(txt,bi,ch):
    """returns list of (bi,ch,v) or None if text is not a scripture reference list"""
    res=[];curb=bi;curc=ch;ok=True
    for part in re.split(r'\s*;\s*',txt.strip().rstrip('.')):
        if not part: continue
        m=re.match(r'^(?:(cap\.?|\d?\s*[A-Za-zÁÉÍÓÚáéíóúñÑ]+\.?)\s*)?(?:(\d+)\s*:\s*)?(\d+(?:\s*[-–]\s*\d+)?(?:\s*,\s*\d+(?:\s*[-–]\s*\d+)?)*)$',part)
        if not m: return None
        bk,c,vs=m.groups()
        # book token may be "1 Cor." -> need to catch the leading digit variant
        if bk:
            k=norm(bk)
            if k in('cap','cap.'): pass
            elif k in B: curb=B[k]
            else: return None
        if c: curc=int(c)-1
        elif bk and norm(bk)!='cap' and curb in ONECH: curc=0
        elif not c:
            # chapter-only reference like "Sal. 33" -> treat as unsupported
            return None
        v=vrange(vs)
        if v is None: return None
        for x in v: res.append((curb,curc,x-1))
    return res
# the book-token regexp above misses "1 Cor." because of space handling; wrap:
def parse_refs2(txt,bi,ch):
    t=re.sub(r'\b([123])\s+(?=[A-Za-zÁÉÍÓÚ])',r'\1',txt)
    return parse_refs(t,bi,ch)
by={}
nq=0
anom=[]
for SI,src in enumerate(SRCS):
    lines=[l.rstrip() for l in open(src,encoding='utf-8')]
    recs=[];ch=None;grp=None;cur=None;anom=[]
    book=norm(lines[0]); BI=BOOKNAMES.get(book)
    if BI is None:
        m={norm(n):i for i,n in enumerate(['Génesis','Éxodo','Levítico','Números','Deuteronomio','Josué','Jueces','Rut','1 Samuel','2 Samuel','1 Reyes','2 Reyes','1 Crónicas','2 Crónicas','Esdras','Nehemías','Ester','Job','Salmos','Proverbios','Eclesiastés','Cantares','Isaías','Jeremías','Lamentaciones','Ezequiel','Daniel','Oseas','Joel','Amós','Abdías','Jonás','Miqueas','Nahúm','Habacuc','Sofonías','Hageo','Zacarías','Malaquías','Mateo','Marcos','Lucas','Juan','Hechos','Romanos','1 Corintios','2 Corintios','Gálatas','Efesios','Filipenses','Colosenses','1 Tesalonicenses','2 Tesalonicenses','1 Timoteo','2 Timoteo','Tito','Filemón','Hebreos','Santiago','1 Pedro','2 Pedro','1 Juan','2 Juan','3 Juan','Judas','Apocalipsis'])}
        BI=m[book]
    HDR=re.compile(r'^(\d+(?:\s*[-–,]\s*\d+)*)(?:\s*\(([^)]*)\))?\s*\.?$')
    CONT=re.compile(r'^\(([^)]*)\)\s*\.?$')
    TIT=re.compile(r'^(.+?)\.?\s*[-–—]$')
    def istitle(l):
        l=l.strip(); return len(l)>3 and bool(re.search(r'\.[-–—]$',l))
    def flush():
        global cur
        if cur and cur['body']:
            cur['body']=' '.join(cur['body']); recs.append(cur)
        cur=None
    i=1
    while i<len(lines):
        l=lines[i].strip();i+=1
        if not l: continue
        m=re.match(r'^CAP[IÍ]TULO\s+(\d+)$',l)
        if m: flush();ch=int(m.group(1))-1;grp=None;continue
        nxt=lines[i].strip() if i<len(lines) else ''
        h=HDR.match(l)
        if h and istitle(nxt):
            rel=h.group(2)
            if rel and parse_refs2(rel,BI,ch) is None: anom.append(('rel not parsed in header',ch+1,l))
            flush();grp={'v':h.group(1),'rel':rel};continue
        c=CONT.match(l)
        if c and istitle(nxt) and grp and parse_refs2(c.group(1),BI,ch) is not None:
            flush();grp={'v':grp['v'],'rel':c.group(1)};continue
        if istitle(l):
            flush()
            t=re.sub(r'\.?[-–—]$','',l).strip()
            cur={'ch':ch,'grp':grp,'title':t,'body':[]}
            # title that is itself a reference label:  "(Ecl. 1: 13-18)"  or "17-19"
            mm=re.match(r'^\((.*)\)$',t)
            if mm and parse_refs2(mm.group(1),BI,ch) is not None:
                cur['title']=mm.group(1); cur['extra_rel']=mm.group(1)
            elif re.match(r'^\d+(?:\s*[-–,]\s*\d+)*$',t):
                cur['title']=None; cur['own_v']=t
            continue
        if cur is None: anom.append(('orphan',ch+1 if ch is not None else None,l[:70]));continue
        cur['body'].append(l)
    flush()
    def clean(b):
        b=re.sub(r'\*\(\d+\)','',b)
        b=re.sub(r'190l','1901',b)
        b=re.sub(r'(\d)- (\d)',r'\1-\2',b)
        b=re.sub(r'(?<=\)\.) \d{1,3}$','',b)
        b=re.sub(r'(?<=[a-záéíóúñ,;]) \d{1,3} (?=[a-záéíóúñ])',' ',b)
        return re.sub(r'\s+',' ',b).strip()
    def add(bi,ci,vi,t,b,own,order):
        if ci<0 or ci>=len(V[str(bi)]) or vi<0 or vi>=V[str(bi)][ci]: warn.append(('verse out of range',bi,ci+1,vi+1,t)); return
        L=by.setdefault((bi,ci,vi),[])
        if any(x[2]==b for x in L): return
        L.append((0 if own else 1,order,b,t))
    for r in recs:
        ch=r['ch'];g=r['grp']
        if g is None: warn.append(('no group',ch+1,r['title']));continue
        vspec=r.get('own_v') or g['v']
        vs=vrange(vspec)
        if vs is None: warn.append(('bad verse spec',ch+1,vspec));continue
        t=r['title']
        if t is None: t='Génesis %d:%s'%(ch+1,vspec.replace(' ','')) if BI==0 else 'v. %s'%vspec
        b=clean(r['body'])
        orig=None
        targets=[(BI,ch,v-1) for v in vs]
        rels=[]
        for rt in (g.get('rel'), r.get('extra_rel')):
            if rt:
                x=parse_refs2(rt,BI,ch)
                if x is None: warn.append(('rel unparsed',ch+1,rt))
                else: rels+=x
        nq+=1
        for (bi,ci,vi) in targets+rels:
            add(bi,ci,vi,t,b,bi==BI,(SI,nq))

res={}
bybook={}
for (bi,ci,vi),L in sorted(by.items()):
    L.sort(key=lambda x:(x[0],x[1]))
    bybook.setdefault(bi,{})['%d-%d'%(ci,vi)]='\n\n'.join('%s\u2014%s'%(t,b) for _,_,b,t in L)
os.makedirs(out,exist_ok=True)
for bi,d in bybook.items(): json.dump(d,open(os.path.join(out,'%d.json'%bi),'w'),ensure_ascii=False,separators=(',',':'))
json.dump({'anom':anom,'warn':warn},open('/tmp/egw/report.json','w'),ensure_ascii=False,indent=1)
print('books',{bi:len(d) for bi,d in bybook.items()},'anomalies',len(anom),'warnings',len(warn))
for a in anom+warn: print(a)
